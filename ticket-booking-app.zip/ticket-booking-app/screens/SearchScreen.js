import React, { useState } from 'react';
import { View, Text, TextInput, FlatList, TouchableOpacity, StyleSheet, ImageBackground } from 'react-native';

const events = [
  { id: '1', name: "Avengers: Endgame", category: "Movies", date: "2025-03-12" },
  { id: '2', name: "Coldplay Concert", category: "Events", date: "2025-04-05" },
  { id: '3', name: "Flight to Dubai", category: "Travel", date: "2025-05-20" },
  { id: '4', name: "Taylor Swift Tour", category: "Events", date: "2025-06-15" },
  { id: '5', name: "Fast & Furious 10", category: "Movies", date: "2025-07-01" },
];

const categories = ["All", "Movies", "Events", "Travel"];

const SearchScreen = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [filteredResults, setFilteredResults] = useState(events);

  const handleSearch = (query) => {
    setSearchQuery(query);
    filterResults(query, selectedCategory);
  };

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    filterResults(searchQuery, category);
  };

  const filterResults = (query, category) => {
    const results = events.filter(event =>
      event.name.toLowerCase().includes(query.toLowerCase()) &&
      (category === "All" || event.category === category)
    );
    setFilteredResults(results);
  };

  return (
    <ImageBackground
      source={{ uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT4zpejGwR1BB-zEjovmsp8lgjcf3EcgE6CAg&s' }} // Replace with your image URL
      style={styles.container}
    >
      {/* Search Bar */}
      <TextInput
        style={styles.searchInput}
        placeholder="🔍 Search events, movies, or travel..."
        placeholderTextColor="#888"
        value={searchQuery}
        onChangeText={handleSearch}
      />

      {/* Category Buttons */}
      <View style={styles.categoryContainer}>
        {categories.map((category) => (
          <TouchableOpacity
            key={category}
            style={[
              styles.categoryButton,
              selectedCategory === category && styles.categoryButtonActive,
            ]}
            onPress={() => handleCategoryChange(category)}
          >
            <Text
              style={[
                styles.categoryText,
                selectedCategory === category && styles.categoryTextActive,
              ]}
            >
              {category}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Display Results */}
      <FlatList
        data={filteredResults}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.eventItem}>
            <Text style={styles.eventTitle}>{item.name}</Text>
            <Text style={styles.eventCategory}>{item.category} - {item.date}</Text>
          </TouchableOpacity>
        )}
      />
    </ImageBackground>
  );
};

/* Styles */
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  searchInput: {
    backgroundColor: "white",
    padding: 14,
    borderRadius: 10,
    fontSize: 16,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: "#007BFF",
    shadowColor: "#007BFF",
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: 2 },
    elevation: 4,
  },
  categoryContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 15,
  },
  categoryButton: {
    flex: 1,
    paddingVertical: 10,
    marginHorizontal: 5,
    borderRadius: 20,
    backgroundColor: "#B0C4DE",
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: 2 },
    elevation: 3,
  },
  categoryButtonActive: {
    backgroundColor: "#007BFF",
  },
  categoryText: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#333",
  },
  categoryTextActive: {
    color: "white",
  },
  eventItem: {
    backgroundColor: "#fff",
    padding: 15,
    marginBottom: 10,
    borderRadius: 10,
    borderLeftWidth: 6,
    borderLeftColor: "#007BFF",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    elevation: 4,
  },
  eventTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#00274D",
  },
  eventCategory: {
    color: "#555",
  },
});

export default SearchScreen;
