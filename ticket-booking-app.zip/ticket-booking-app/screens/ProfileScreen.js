import React from 'react';
import { ScrollView, Text, Image, FlatList, StyleSheet } from 'react-native';
import styled from 'styled-components/native';

const user = {
  name: "Sumaiya",
  email: "summi@gmail.com",
  profilePic: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ3Up3ugBAa9HqTYHNpPhzNUjEMesYsIIDL-Q&s",
};

const payments = [
  { id: '1', title: "Flight to New York", amount: "$250", date: "Jan 12, 2025" },
  { id: '2', title: "Concert Ticket", amount: "$75", date: "Feb 5, 2025" },
  { id: '3', title: "Movie Ticket", amount: "$12", date: "Feb 18, 2025" },
];

const ProfileScreen = () => {
  return (
    <Container>
      {/* Background Image */}
      <BackgroundImage source={{ uri: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUSEhIVFRUWFxcXFxcXFRcVFhgVGBYWGBYVGBUYHSggGBolHRcWITEhJSkrLy4uFx8zODMtNygtLisBCgoKDg0OGhAQGy0lICUtLS0uLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAJMBVwMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAEAAECAwUGBwj/xABBEAABAwIEAwYEBQEFBwUAAAABAAIRAyEEEjFBBVFhBhMicYGRMqGx8EJSwdHhFCNTcrLxBxVDYnOS0iQ0gqLC/8QAGgEAAwEBAQEAAAAAAAAAAAAAAQIDAAQFBv/EACURAAICAwEBAAEEAwEAAAAAAAABAhEDEiExQRMEIjJhFEJRM//aAAwDAQACEQMRAD8A9BbgWh0ifdDVMJUaSWkETMfyre8cLgSoDiQglwIi0HWVdWT4Uvx2Wxm6kHscJnRQxOHbWHny191k8RodwAc5E2E/RPFJiNtD9pME2uGjNAbfncbrzDENAqGHSATBG67jiVUCIdDvi16Xhc0/hbqkubuSV3Yf2rpCfWTpV2uaGuFrXWhgsDlfmHwkD3VXD+GggZri/SD1V3EagpRliOh08wn94iZn9pKsHIBrcrAyo7HYs1DfZDAKiVAspLSk2UbQJJDYCNpYNpuPUdUxrMlgKLw1TYko93DhBIKzKlMtQ9ARqm+pUACVbRufEtpuAAjeeWo9Fm6CZNVxIEzpqq2MdyW1XweQQQb9FVQwZOiFqjGS5p6ojDYYvtN10XCaAc7K8B21xZdTheFUm6U236KU8uo0Y2eenAlh8cxsouIA3Xf8R7PtqAZXR6Kh/YVjm2e6edkqzx+jPHI4ZlaBr6FE4WpcanYdFvVew9QTDgVmt4PUpu8Qgj1VFOD8Yji16E4imAJEk6SUsFhHESLyiKGDL2wb38iuj4VhGtbAUpTpDRVsyafD8t3EnohsfQPI5QF1H9IZuP2VWI4feQddlNZOjuBwz8ORcSfpHIKurWIiPruuqxPBnD4SZ6oB/B8hzPgFV2ixKaAsDiKsiSYXRYMv3lAUcgIuJWtQqBRmx4hTJCMpPQlO6LptXOyqCWOT94oMUiUg5MPThyqlMKqAQhOEG7EgKH9YFqZrDyAqXgIOpj4CCrcUG5HuioMDmkF4lgKSwcZxgtMZXdJsCOkpK8cUqJPJE6jBNgALF7Z4UGmCPCXODS6SInQn1j3Wvhq8oXtFXaKXiEiQT5A6qMG1JFZeFHZvBOpUw19QuOsxCbtbgH1sO5rB4wQW+huOllRw3ioc4wSRNrLoqTxEoycoz2AqcaOE4TwWtXaGxLm2LSILdvEVZxDgNfDNl7ZbeSzxZf8AFGgXpnDcGG+I0w10ag3IN7geQRNan0lN/ku/AfiVHhtbEtYJzS534QbDmSs7EYcvdLnZWyMzyHFrJ0nKCY20Xp/F/wDZ/h6zy9rnU5/CyMoN5IB02sI0UOC8Gq4NwoFrH0KhcS+PGTAy03E20kjnfTQ9X+RCrXpH8Ur6ec8S4B3My5zp7stcGQwtfnMzmt8DhHMbInhnZ2nUc4HEs0/s4IHeEES2HGWugwGxqdwCuq4twNlB1GmK9fuXvIDQ4uawt+CmxotJcTcgxA5FH4anml+UudTfUzvAY17XxNZjWvD2uZM6Bol1pkrPM9bTNorMM9hqWQ1f6ipRaGzNZjBGupDhbT352GKey+Ka45abqjJs9rXNBvHwvAd6xHVdGeKA121K4Lm05aGOaJbaPgdLWu0my7vheMZWpNqUxA0i0gi0W+4ISyy5MfX00YwnxHleG7N4wjMKJiDqQDYkEQTrYoHFcNcKhp1Rlfu0r2otBEESOREri+29dtJzGMYxuYEuORsxPwtkWBMklu887nF+plKVUGeJRV2cjV7NODC/Yfd1CkBlDi6Y3vIC7XAYxj6cWEjQrOxIwrPgZNQ/FnJAaZAtlIB/EbzoE/5W+NE9V6gGgadZsbDQnmpf7ke0yAS2JBAnTWR+q2OH8OafG0ATyMDzhbdChqXmIuTc6nYbkkqUsuvg6x36cZw/hhzTHyg/NdRhHNaAHFxJ/wCUER78pRraI1DdT53j6rWwGBbEua0mbbx0gixUsma/SkMdAhwZAlzbc/2UqbY0C130g74rjltPMqTaTYIgQei59i2pjvpl/wADRYX0PrJ/ZCYngb3E2FhudT0XSNYAIAhQJ6oqbXgHFP04/B9mH5waji1usMIzDQgGQdb+UdUXV4IKbswxGUOP/Egy4xPikX6Lo3uABJNgCT6LC7W4Zr6QpkEuLvDDoywDLo0OsR1VFklKXWI4JICbiwS5k3aS0nS4MTClnaNXLGw3DMlg4ytOlSB+Ie6q4peE1JllUSJEFcPxXtThM7mP7yWuIMNtIMGL9F34ptIgLwXjrf8A1Fb/AKtT/OUcYWjsafajAjQVZ55AT5aqbu2GFmQKn/b/ACvPYTtCprYKR6VQ7d4caip/2/yul4RxiniGZ6RtpBEEHkQvFGhd72DrhlGoTs//APISTxquBTo9ADyourwsRvFg64MBNX4hb7Cl+Nh/IjTq42N1nv4kQsvFY9sATfe2izq2JOW0zz6KscROWQ33cRMSfmVl1+JPBsYHP9lk0mVqr8lNpcTsNh12A6ldVwrsxk8WIdnOuQfAPM7n5eaM3DH1mipT8KcG+rWEMBA3cdPffyC2OGcGYwhx8bvzOGnkNkdSp6AAADQCw9lp0KELhnmcvOI6o40vQbFcOp1WZKjcw15EHoRoktFlNJKpyXExnFP1Hn3D+KkAN3RuJw7quWTYGSDeRyXDMx8PzB5cCIO0LpuHcXAAAJd9V6M8TXUckZ3xm6MKGgFoDfkERh8bNjDSLSSAPcoSjjy8QWmPb3QOKf3bgGNeZubEj32XPq3xlbrw7j/fQDWwATuZtpsTf1hX4Lizavh0cNeR8lwmCxBqCzudtCuh7PUsr2TJJkT6G6nLGojKTZvvBF0+Rrmw4Ag7EAq7In7tJY9GHieC4YO7wtFPKAMwcWNDRGonKPhAnVZleiWFzsKKoNZ+ckDM3KAQSxswSSZny2iTu1uDcQ15JNNl3NGkzZxG/wCis7PYZj2k7QIi2u/y+7KylUdrJNXKjG7XcLzMbW7tratu9AcJANhb8VxE/VGdhMO5tF0/CXS3mTo76Aeil2gZUdkDjlfBy2B0MHT091bwLGmnSNN4JeCS0xZ0xGml07m3ioRRSyWa+NrtYJc5rdYzOygmNJXl/G6xxFUPa5zg0ZQHRM6uIsJE6GBYCy7jG0y8eOXHqdPLksXjeGaWtc2gymc3ieLudYiLCwuPZH9O1F/2bLbRjYWm4t8An5fNa/ZrsvUcTUqRrfNqDraLFEdn8PBDNnGxNwuursFNjWNMNLoLpggbxG+3RNmzNftQMeNPrAanDHNmIIHKxjyVmHwrnCwESDJ8tvQ/NaD6TagBINjaQWn5jRELkcmdGoGzBljSG3NiLaO6n8v8opjY5enSw+SlKaUoR0pTJnFAw7ihMbim0253TEgW1kmBqiZQXFMCKzQ0kiDNucEfqU0avoJXXAB2JFWpTtlAJFzqCRqPT5obiADKrgXX1vyNwL6oDEtFN2WSbwLxcWPz+RCvrAVHZ3G5ifRoH6LpUEqfwhtfPpYyoPsIXEUA50lx0iJEKxtINMyIUxlPKU3ngPQCm4t1XjfG/wD3Fb/qP/zFe14/CgiYnovEuLiK1UHXO7/MVWNPoq46A1Y0KsK0JhiTQut7MYYvpP8AFDQbjmYG65Nq7DskCaboMeL9BssLLw3RSDQMrR99ULjQ4RYX66IxtN1pKJwnCnVTazRqTf8A1KVyUesRJy4jEbhXGDEkn7C2OH9lnv8AFWJY38o+I/8AiupwPDmU7gS78x19OSur1Wtu5wC5Mn6tvkTohgS/kDYXCU6LclNoaPmTzJ1JSgkrL4n2jps+EFx6fuuO4n28qUzmaB0ErldvrOlUj1fC4SNUW2muI7Gf7QGYloFVvdnSToeo6fzyXoFEAiRdYxGmxJEBqSJj5yovyzbXVE4fEuJhp12/lBknmisDXyTAud19C48PJ2NnBcV7sgPdm9zB/wAW62sBxzvCWlpBNhaZHmubwWIaXDNHJddw5jJEQuPNGK9RfG2/pNuBAcHCQ6/K8rf4LTc54EkRc8wNP2WZjyQBGp3Wv2YrXe06w2CTcgTMfJck7cbOiPp0bQVJQaOqkucqRqXsELgMEKFJtMaNETFyQNfNFkxdYvEOKvIPdCAJu4Tm5b6IpN8QHS6S4k9lRstaSW/iiwmJBPkFlYVzGkib8k+GzubmOp1EAeltlVUwLg7vGyTu3T2V4xrjZJv6jSqYlsXQRrsJhxhu5Am3kmjOIAIKhw/g0wHOJJOqKUUugbb8D6WG7wsdTIBLRmAtlj4SQBYkR6rW/o9Jd4WmQ2N97lU0R/TsyuOa/hA1i06pqXETIlsAwDza6YvMZmm1xopO34UVI0QUmuQ9ZznECmRaQ48jpHzm3IKbKTiwtNjEAgz6zqkGL4Ue76qjhlUFkARlOXWfVFreG9IZUipFqaEDDZVGo0AEkwBc9E7rLKx2KyuLKjjkeDJAgNBMCDeYi469UyTfgG0jluLBr6tZ5eAA4FupJgBmURoDAvcac1j/ANW4EECYN7WttddZ/Ts7t7nuu9ha0DroSD5Bc0+xyzb0E8pXpYmmmjgyWnZ0WBNHFU50dOghrmm8CN7c5mEDV4TUpOknM3npHmJWHWoupuD6ZLX9Iv0I0I8103Z7tF3v9lUbDwJMaEDUj30UJRnj6uotFxye+lVFwJDXP1tYZvKy4Op2Cxz8W94pUiwVc4NV+Wm9ubNBDZfBFjbmvX6LGgeACOgA/wBVzvbTtnSwLMrYfXcJZT5aw+oJBDJEWufmJLLJv9pZQSXTO4v/ALPcG5xxNZww7AJqtpuDKU7ulw8I8onz15nH9ouGYYGngcGys6CO9qguZ6Z5e/8A+o5Ll+I8Wq4sh+KxDnOEw3L4G3/C1thYuvE2AkqgYej/AHrtD/w975RrobX2ndVjB/7MVy/4UvqZnF0NEmYaA1onYAaDoux7E0MzH/4v0C5B7RJDTIkwSIJGxjZdr2BPgqf4tfQK6/ojPw6bDYDO8U80dTy5DmVu+GmMrQbeg/crFfimDQyURhuNMqQyqYds/byP7rnz45S78GxTiufQirj3G2nkgazM2t1pOw7esql2HbyXNqvhdSf05zHYUawuF4hwGa7TUfFNxO8AmCWsn8MmBPVetOoN/KP4Q2JwVNwgsaZHKxR1DscVXoikIpht9BERGVpluuUctQui7L9rnYdzaVUl7CNd2i17fhQ7qgoPDXiaegfElgn4XfmbyOo6iyox/DhBczLLhMW+KJblI1HX15pJRsZSPYMJiG1Gh7CCCJBCS8b7PdpauCdk+Nrp8JtcTJH5Lx/qkptNDrpzgpqQpovuk4pr6WzxQYU1scOxzmkEzrqhqbDYcpPvH7I/B4HORLh97KWSq6NFu+GvjuJiGTzR/Ascc4IJbq1u93AgH3IVGG4I0gTeFrYfhbQzJAjovPnLGlSOyKndnXYaqHta5ujhP8Id3EReGk8jIE9fJBcEqd2zu3km5Id58+R6p3YSGSDn0AyzEDUn2XHSs6b4TxuJc+APC0tkjcySInlb5oJzYspUyTqI6idPLdWAbap1wV9BaboMSjS4KDKAAsqnthH0CtEKovZX4Rpc4AEjqNkLVM62WxwwDu25d7nqUZcQF1hBoNLvFLjzJ06AC26pr4IzLYj8ukW+/dEtbB++icEk6qSZSgJ2DqAktfE3NzcjmjqXwi82F9Z6yoFyoa/I7L+F128gfxD5j3W9N4W08QwkgEBwMEaGdjG82urcyBxppN8dQCTYTcnoFlUcYQQ4QPXbl11TxhfgjlR0ec8k2ZD0cUDTDydr+eke6HpY0yS74eVrewklKkGzSBWN2hc0saIkzMcmgQT5SQPVEY01CyaR8VjyJGpAmwMLnWVTUcA7MJN3QCY2kquKHdieSaqjPxlLS+gAAs6NZE7STKzqgvaLeXy+a0sRRJ1Ze3Mn1ugTR5r0oVRwTsHz87rS7NCn3tN/eRVzOaWEWLXNMZTzlCvoEcvvrNlZw/AkvbUbH9m9jiJgwXD9EuanBjYW1JHZY+qKTHVTbKCT16X3OizcThsJxGjlqNDxsdHsd0OrT9eqj2uJ7gNn4nieoAJjymD7LlcMx1N2am4tPMfrzXHiwbx2T6dWTPpKn4c72k7AYjDOJp/21HZ4gObyD2/qLeWixmcCr/3Z92/uvXcH2lMZazOmYCQfNp/RF0OB0HnMMwDoIaDAvyMTCop6cyA/n/5njY4FX/u/mF03Zzh76TDnF3GYXYcTdh2ju6LGk7v10OjSdfNZwaunH3pzZJv+IPUb0Q76K0cig6kqEbH4dxMshlSS3Z2pb+4W2KoPIg6EaELnH0lPCYl1O2rNxy6jkVx5sF/ugdWPL8kbrx7IV7rq2lXBEgyDv+hUKzFyRLttAOMwwdyIOoOi501X4dzmgl1MGQNXMnXLzHNu/Q3W1iMUWPDAHPe7RrdfXkEPjuH1XSXUwPJwLh+6olbo2/LMriGSoe8BEHcaETbrIm41BKdZ7aT6TiWiQfiaZAJ2PMHySTvGDf8As0RQTiitKmwjREBmbXL7Qfku9zo4ErMgUlbRaWmRYrTdhREAAnmD+im3AE/C06bpfyL6HV/CeBx5Gq6HCYwOCxKPC3i+nRauEoFq48qg/Drwua9NJj1dSfGm4g9Qf1Q7DzCnZcrR1Jh+Cw7XAn0/lW1cCI8JM8j9FdhAMgjl891cksajDrNc2xEId9RbmJw4frNtI6rLxfDi0ZswI3tBuYCpFr6K0wZpHJH4XGD4XECNDoI6nZAhpiAqS7Lcg+yfTYRz1NtuOZI8WvIE+5AsiaJtIuDyusEP3WtwysC3Lu35gzf6pJQro0Z2XliT2ZgQfTn5hWlC8RrOa0ZbFxieQg/NIlY7dGXjMGzNpmj4i45jMgxJ5RtzQ1bh4tBMe8ac/JEsdsp94IsuhbIg9WVUGua0tJlpg9REfWAmzGzYP6e6sc7/AEUTiWjdamwbJfR3vdTktOWfCfOJBG2kwUE3DBrHPAhrYEm8kmIHNaYqNczKbmZbtrqD7kqniWKOVtNzYbLST+ZovERaTHzWjflAlXpjYrGgxkBFr6czpG0QgHuJ81oHLmMiW5pjTwgmOswT6oscHD2Z6Tp1lpEX5D79V1qUIenK1Kfhgln37Kiowi4kHmOi0zR+9xtfkoPoqtpk7aDu0ollLrJ+Q/dY1OktbH1g9lIbtaQfPwj9EM2kp4f2wSHzS2naAqlFb9LFZcG1w+IeAHkQ7/xCzu6TZDGWTEzG084WyRU6sGObjYO8SS4gSTNtJOqm1iuFJTFNNsID92oliji8a1hj3/bzRZpkWILTyIIPsUNw6sDdTVL6S0MiZ1FDYJm08zDI9RsUTVxcMLmtLiBOUCT7DX0UMdUbTEnU2AGpPILR4HwF4Pf15DyPCzZgP5uZ6beenJncffp1YFJ8+DcA4XkaatS9Wp8X/K3UMH1PXoAjsRhvZWmWlWseCoRkXcDmuJ8HFS4s7nsfNJdDUopLoWThJwOabQReHw7TqEQ2ipiirt2cqVMto4Rn2UZTpgaBAikrGkhQlBv6dEcqXwPBUw7ohmPKskqTjRdTTLcwSygqo+RUQR1CGrDsjRwmJDLGY94WlKwA07FbtE+EeQ+iSSoeLJLK4tJcGzYCY6km/wAkdjqpayxgmALT92lYzwSZJk8zcowXbNJlHdvnX1VvdmL3VjJHVWMDT0VtmR1RUAdgtDhYHitB/T7lDlvVX4J8O87JZO0NHjNBZ3EcQCRTGuYSdhbT5hHYisGiT6DmeQWMXXzGC6Znqkxq3YckqVCxfgOUeKAJI1ny8oQj6g2JHlaT1CuMSSYJNyevondRaei6Y0vTklJvwEfVJTMqHcD6fRW9yn7hUtEbZDvjsAEhXfpOvTdWCitrCYJrQDlBdYzrfopznGPwpjjKfjMvD8Hc67zAi3MHlHz9UM2k8MfDnBrXNtpubxsZiw5rqIVWJoZmubz+u30Cisz+nQ8C+HKVBJLoAkzYQJ3so90jhhjyS/pjyK6d0cerAe6S7pH/ANK7kmNAjZH8iNqwLu0xYi+7Td2huZRBhTQ2PrimwnfZaLwAJNoWdg8J39QPfGQHwtP4oOpG7ZHqbaApJ5KQ8Mbk6K+zfCS54rVIBMljTq2dKhEzmMy3kL8lv1qLangygETBBiCCLMtB6jS2xuLiQ0ZXgyJLSBMnWRvm5g/NQbmAY10NA3EHSPDcQDOp89dVxObbs9KMEo6mTUolph3odjz8iNxqE2Raz2gjIQ3KPDmgwY2tuDvtfqgKtIs1MtmJsYMxDo+u/Q2XRDNfGceXBr1eC7L8La8nFVBmdmcKYOjA0lsgfmkG/wC66F7FmcGxTaYNNxhpJLTsCbkH1v6lbRaoTvbp1YmtVRmYigs6owtNlvPpoSvQSlKAqVQFJQdQINkk2xPRkBSUhSRIYnDF17HHqD90l3SKDU+VCzagndKQaUTlT5FtjalLZVgcrA1PlSumOm0QBWpTeAwEmwA+izsqJMdyR6e50UpotCYJXqF7pkxsDFtJ0VWRX5E+ROlQjnZS2mpd2rITwjYjaKshT3VsJQtYLKC1N3aIhKFrFfQbuku6REJQjsxdUDd2pBivypZVtgUU5UYccYAa33O3oqcqfKldP0aMnHwLwmKLrEX6aQrq1XKJ9hzPJAU7GQQDzKZzi4yT5bCPuFNx6XWVqPfRT1n0Ue8KfKnc3Tyn/X5JuCbsQdOyg5n3KkQorGc7KzT6KJZ0VhTI2LYBisMXkM/DvtPITsOZ/VEluQFhYHA/DlECdANfDA0M6BSe3koQHkB9wPwnQnmefl9ic7fTowyj4KoTLW1HCNbGJNoBOsSdtbJw7chzmxDSdYk7dTYHoqWuy53NbnaBlknlPh5lgNifrClPwguzg3gCZjeB+Dod41UjoJucWgBxAFtCZECcoOsaXGwPRSk6CS2SJgH/ABgA6ibXnfzUW2l4Ay3Avo2ZkHQAnbkB0ArcIAvmDtWgagAkgAXyiRM6+sLGKMThss5fE3cQZFpkTqOlyOoV/DuJ5AA45mbEXLR+o++isDzBy/D5jaC4jZsfzsJExWFmX0vMi2Uz1mA7rod4Ny6lfGQljcXtA6NpBEggg6EaKD2LB4fjSzSSJ8TDYg72Ojvr81v0arXjM0yPp0PIrNUPGakDPop0S5qSA5mwnhJOF1HCKE6SdYwgE6SSxh08Jk6BhQn++iaUkAjAJ0klgChPCSSwBJJSksKJJJJYwkkkljCSTpIAFCUJ0ljDQknSWCLNyt1/bl5qOmiclRQDYiUxSTLGIlMnKiUDCVdRkqZKiSsYg2sRItOxNhO0nbzUf6dzRLTmduCIBMkiOVybT66lSeFCnVy2Nx8x/CSUf+HRjy/GQaR4YlxmSHHcbmbNMmw57WJFwdq7QciNRMX3zE6R5ap6lKfE0weex6Hn9R8kMwaAAh4uSb7fFb4yZsdr8oMzpJkTzLibja1zIPwtEjzm8kqcnxOnJA3tt4nE7R+k3tCzXJJ8QgQL+Qj8Uk7xE7XUe62y+MkSTpa+YkaiwhvQRF4xiFegHmWS14GpnTkWnxOHzG35TDD4hzHfldu06OGx6jr/ACiXOuczspaJtfzcdzyA/XSt9AOAaWZSBIM5SNPENfEZvz32TKVE5wvq9NbC4ttQWsRqNx+46pLnXEsMOMHQOBgHmD+V0be0i6SakJ+VrjRrSpBJJdBzjpJJLGFKUpkkDEwnCdJYI6ZJJAAkkkljMQTpJLCsSZOksAZIJJLBHSTpLCjBOE6SxhJJJIGEmTpLBIlMkkgEimSSWMMVApJIGGKgUkljECoPSSWCPgz4o2gn1hWY8eBzvxNBc08iPvRMkpyOrD/EbEDLSJGrQI3gyL33uVFwnOTctIDeg7trrep9bck6SQsSDfC47w53/wAvFf5BSwTc5h14pgj/ABFzxNt4Av58ykksYbAUw9rQ8BwOoIEG2a43vdJJJFAZ/9k=' }}>
        <Overlay />
      </BackgroundImage>

      {/* Scrollable Content */}
      <ScrollView contentContainerStyle={{ paddingBottom: 20 }}>
        {/* Profile Section */}
        <ProfileHeader>
          <ProfileImage source={{ uri: user.profilePic }} />
          <UserInfo>
            <UserName>{user.name}</UserName>
            <UserEmail>{user.email}</UserEmail>
          </UserInfo>
        </ProfileHeader>

        {/* Payment History Section */}
        <SectionTitle>Payment History</SectionTitle>
        <PaymentList
          data={payments}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <PaymentItem>
              <Text style={styles.paymentTitle}>{item.title}</Text>
              <Text style={styles.paymentDate}>{item.date}</Text>
              <Text style={styles.paymentAmount}>{item.amount}</Text>
            </PaymentItem>
          )}
        />
      </ScrollView>
    </Container>
  );
};

/* Styled Components */
const Container = styled.View`
  flex: 1;
  background-color: #f0f4ff;
`;

const BackgroundImage = styled.ImageBackground`
  position: absolute;
  width: 100%;
  height: 250px;
  top: 0;
  left: 0;
`;

const Overlay = styled.View`
  position: absolute;
  width: 100%;
  height: 250px;
  background-color: rgba(0, 0, 50, 0.3);
`;

/* Profile Section */
const ProfileHeader = styled.View`
  flex-direction: row;
  align-items: center;
  background: rgba(255, 255, 255, 0.9);
  padding: 15px;
  border-radius: 10px;
  margin: 180px 20px 10px;
  elevation: 5;
`;

const ProfileImage = styled.Image`
  width: 70px;
  height: 70px;
  border-radius: 35px;
  margin-right: 15px;
`;

const UserInfo = styled.View`
  flex: 1;
`;

const UserName = styled.Text`
  font-size: 20px;
  font-weight: bold;
  color: #001f3f;
`;

const UserEmail = styled.Text`
  font-size: 14px;
  color: gray;
`;

/* Section Title */
const SectionTitle = styled.Text`
  font-size: 18px;
  font-weight: bold;
  color: #001f3f;
  margin: 20px 20px 10px;
`;

/* Payment History */
const PaymentList = styled.FlatList`
  padding: 0 20px;
`;

const PaymentItem = styled.View`
  background: #ffffff;
  padding: 15px;
  margin: 10px 20px;
  border-radius: 10px;
  elevation: 3;
`;

const styles = StyleSheet.create({
  paymentTitle: { fontSize: 16, fontWeight: 'bold', color: '#001f3f' },
  paymentDate: { color: 'gray' },
  paymentAmount: { color: '#007BFF', fontWeight: 'bold' },
});

export default ProfileScreen;
