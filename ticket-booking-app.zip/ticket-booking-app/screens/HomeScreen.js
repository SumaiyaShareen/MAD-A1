import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, ImageBackground, Image } from 'react-native';

const HomeScreen = ({ navigation }) => {
  const [selectedCategory, setSelectedCategory] = useState('Flights');

  const categories = {
    Movies: [
      { id: '1', name: 'Avengers: Endgame', showtime: '7:00 PM', price: '$12' },
      { id: '2', name: 'Inception', showtime: '9:00 PM', price: '$10' },
    ],
    Events: [
      { id: '3', name: 'Music Concert', time: '8:00 PM', price: '$50' },
      { id: '4', name: 'Tech Conference', time: '10:00 AM', price: '$100' },
    ],
    Flights: [
      { id: '5', name: 'Lahore to Karachi', airline: 'PIA', price: '$150' },
      { id: '6', name: 'Islamabad to Multan', airline: 'Airblue', price: '$120' },
    ],
  };

  return (
    <ImageBackground
      source={{ uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSYU0-feQhl0peHQBr3sMpjz0W6sNu_tQ_F98LFyViVCI5DELWoRYZk5dgxlDgxC9i9_Lg&usqp=CAU' }} // Replace with your background image URL
      style={styles.container}
    >
      {/* App Title */}
      <Text style={styles.title}>Booking App</Text>

      {/* Rounded Airplane Image */}
      <Image
        source={{ uri: 'https://www.lufthansa.com/content/dam/lh/images/offers/fareteaserdynamic/DestinationFinderCard-square.png' }} // Replace with your professional airplane image URL
        style={styles.image}
      />

      {/* Description */}
      <Text style={styles.description}>
        Find and book flights, events, and movie tickets in one easy app. Your journey begins here!
      </Text>

      {/* Category Selection */}
      <Text style={styles.selectCategoryTitle}>Select a Category</Text>
      <View style={styles.categoryContainer}>
        {Object.keys(categories).map((category) => (
          <TouchableOpacity
            key={category}
            style={[styles.categoryButton, selectedCategory === category && styles.selectedCategory]}
            onPress={() => setSelectedCategory(category)}
          >
            <Text style={styles.categoryText}>{category}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* List of Bookings */}
      <FlatList
        data={categories[selectedCategory]}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.item}
            onPress={() => navigation.navigate('BookingDetails', { item })}
          >
            <Text style={styles.itemName}>{item.name}</Text>
            <Text style={styles.price}>{item.price}</Text>
          </TouchableOpacity>
        )}
      />
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.3)', // Semi-transparent overlay for text readability
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#007AFF',
    marginBottom: 20,
  },
  image: {
    width: 150,
    height: 150,
    borderRadius: 75, // Makes the image rounded
    marginBottom: 20,
    borderWidth: 2,
    borderColor: '#007AFF',
  },
  description: {
    fontSize: 16,
    fontStyle: 'italic',
    textAlign: 'center',
    color: 'white',
    marginBottom: 30,
    paddingHorizontal: 20,
  },
  selectCategoryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
  },
  categoryContainer: { flexDirection: 'row', justifyContent: 'center', marginBottom: 15 },
  categoryButton: { padding: 10, marginHorizontal: 5, backgroundColor: '#007AFF', borderRadius: 10 },
  selectedCategory: { backgroundColor: '#0056b3' },
  categoryText: { color: 'white', fontWeight: 'bold' },
  item: {
    padding: 15,
    backgroundColor: 'white',
    marginBottom: 10,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  itemName: { fontSize: 18, fontWeight: 'bold' },
  price: { fontWeight: 'bold', color: 'green' },
});

export default HomeScreen;
