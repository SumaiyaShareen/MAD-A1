import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, ImageBackground } from 'react-native';

const bookings = [
  { id: '1', name: "Avengers: Endgame", category: "Movies", date: "2025-03-12", status: "Upcoming" },
  { id: '2', name: "Coldplay Concert", category: "Events", date: "2025-02-10", status: "Past" },
  { id: '3', name: "Flight to Dubai", category: "Travel", date: "2025-05-20", status: "Upcoming" },
  { id: '4', name: "Taylor Swift Tour", category: "Events", date: "2024-12-20", status: "Past" },
  { id: '5', name: "Fast & Furious 10", category: "Movies", date: "2025-07-01", status: "Upcoming" },
];

const MyBookingsScreen = () => {
  const [selectedTab, setSelectedTab] = useState("Upcoming");

  const filteredBookings = bookings.filter(booking => booking.status === selectedTab);

  return (
    <ImageBackground
      source={{ uri: 'https://www.lufthansa.com/content/dam/lh/images/offers/fareteaserdynamic/DestinationFinderCard-square.png' }} // Replace with your image URL
      style={styles.container}
    >
      {/* Tabs for Upcoming & Past */}
      <View style={styles.tabContainer}>
        {["Upcoming", "Past"].map(tab => (
          <TouchableOpacity
            key={tab}
            style={[styles.tabButton, selectedTab === tab && styles.tabButtonActive]}
            onPress={() => setSelectedTab(tab)}
          >
            <Text style={[styles.tabText, selectedTab === tab && styles.tabTextActive]}>
              {tab}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* List of Bookings */}
      <FlatList
        data={filteredBookings}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.bookingCard}>
            <Text style={styles.bookingTitle}>{item.name}</Text>
            <Text style={styles.bookingDetails}>{item.category} - {item.date}</Text>
          </View>
        )}
      />
    </ImageBackground>
  );
};

/* Styles */
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  tabContainer: {
    flexDirection: "row",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
    borderRadius: 15,
    padding: 5,
    marginBottom: 20,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    elevation: 4,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 12,
    alignItems: "center",
    borderRadius: 12,
  },
  tabButtonActive: {
    backgroundColor: "#007BFF",
  },
  tabText: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#555",
  },
  tabTextActive: {
    color: "#FFFFFF",
  },
  bookingCard: {
    backgroundColor: "#FFFFFF",
    padding: 15,
    marginBottom: 12,
    borderRadius: 10,
    borderLeftWidth: 6,
    borderLeftColor: "#007BFF",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    elevation: 4,
  },
  bookingTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#00274D",
  },
  bookingDetails: {
    color: "#555",
  },
});

export default MyBookingsScreen;
